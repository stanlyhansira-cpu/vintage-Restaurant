# Vintage Restaurant & Cafe Gampaha

A full-stack restaurant website built with React, Vite, TypeScript, Tailwind CSS, Express, and a local JSON data store. Customers can browse the menu, place orders, submit reviews, and contact the restaurant. An admin dashboard is included for managing restaurant content.

## Features

- Responsive restaurant landing page
- Menu browsing and food details
- Shopping cart and checkout flow
- WhatsApp/order integration
- Table reservation form
- Customer reviews
- Gallery and newsletter sections
- Admin dashboard for restaurant management
- Express API
- Optional Gemini API integration
- Optional Supabase configuration

## Requirements

- Node.js 20+ recommended
- npm

## Run locally

1. Clone this repository:

   ```bash
   git clone <YOUR_GITHUB_REPOSITORY_URL>
   cd <YOUR_REPOSITORY_FOLDER>
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Create your local environment file:

   ```bash
   cp .env.example .env
   ```

   On Windows PowerShell, you can use:

   ```powershell
   Copy-Item .env.example .env
   ```

4. Edit `.env` and set your real values, especially:

   - `ADMIN_PASSWORD`
   - `ADMIN_SECRET_KEY`
   - `GEMINI_API_KEY` if the AI features are used
   - `APP_URL` when deploying

5. Start the development server:

   ```bash
   npm run dev
   ```

6. Open `http://localhost:3000` in your browser.

## Available scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the Express + Vite development server |
| `npm run build` | Build the frontend and bundle the server |
| `npm run start` | Start the production server from `dist/server.cjs` |
| `npm run preview` | Preview the Vite build |
| `npm run lint` | Run TypeScript checks |

## Production build

```bash
npm install
npm run build
npm start
```

Make sure the production environment contains the required variables before starting the server.

## Environment variables

See `.env.example` for the available configuration. **Do not commit `.env` or real API keys/passwords to GitHub.**

## Security notes

- Admin credentials are provided through environment variables.
- The repository does not include real secrets.
- Use a long random value for `ADMIN_SECRET_KEY`.
- Use a strong unique `ADMIN_PASSWORD`.
- Rotate credentials immediately if they are ever exposed.

## Project structure

```text
.
├── src/                 # React application
│   ├── components/      # UI components and admin dashboard
│   ├── context/         # Application state
│   ├── data/            # Default data
│   ├── i18n/             # Translations
│   └── assets/           # Local assets
├── public/              # Public images/assets
├── server/              # Data storage implementation
├── supabase/            # Optional database schema
├── server.ts            # Express API + Vite server
├── vite.config.ts       # Vite configuration
├── package.json         # Dependencies and scripts
└── .env.example         # Environment variable template
```

## GitHub

Before publishing, review the repository for secrets and personal information. Keep `.env` local and commit `.env.example` only.

## License

No license has been added yet. Add a license before distributing the project if you want others to have explicit permission to reuse it.
