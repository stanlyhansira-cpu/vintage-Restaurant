# Vercel dependency fix

The Vite stack is pinned to compatible versions:

- Vite 8.3.0
- @vitejs/plugin-react 6.1.1
- Tailwind CSS 4.3.3
- @tailwindcss/vite 4.3.3

`.npmrc` enables npm legacy peer-dependency resolution as a safety net for Vercel's install step.

The project requires Node.js 20.19+; Vercel should be configured to use a current Node 20/22 runtime.

After pushing these changes to GitHub, redeploy the Vercel project.
