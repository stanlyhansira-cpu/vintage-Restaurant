# Publish this project to GitHub

## Option 1: GitHub website

1. Create a new repository on GitHub.
2. Give it a name such as `vintage-restaurant-cafe-gampaha`.
3. Upload the contents of this folder.
4. Do **not** upload your `.env` file or real API keys.
5. Commit the files.

## Option 2: Git command line

```bash
cd vintage-restaurant-cafe-gampaha
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

## Before pushing

Create `.env` locally from `.env.example` and set your real secrets. The `.gitignore` is configured so `.env` files are not committed.

For deployment, configure the same environment variables in your hosting provider's secret/environment settings.
